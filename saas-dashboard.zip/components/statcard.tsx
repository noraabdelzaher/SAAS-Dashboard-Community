interface stateCardProps{
    title:string;
    value:string;
    icon:string;
    iconBg:string;
}

export default function stateCard({title,value,icon,iconBg}:stateCardProps){
    return(
        <div className="bg-white border border-[#FFFFFF] p-6 rounded-2xl flex items-center space-x-4 shadow-sm flex-1">

            <div className="w-12 h-12 rounded-full flex items-center justify-center text-xl" style={{backgroundColor:iconBg}}>
                {icon}
            </div>

            <div className="flex flex-col">
                <span className="text-2xl font-bold text-[#1A1D1F]">{value}</span>
                <span className="text-sm font-medium text-[#6F767E] mt-1">{title}</span>
            </div>

        </div>
    );
}