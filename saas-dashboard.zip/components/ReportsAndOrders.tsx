'use client';
import React from 'react';

export default function ReportsAndOrders() {
  const orders = [
    { id: '#876364', name: 'Camera Lens', color: '#FFD2D2', icon: '📷' },
    { id: '#876368', name: 'Black Sleep Dress', color: '#CABDFF', icon: '👗' },
    { id: '#876412', name: 'Argan Oil', color: '#B5E4CA', icon: '🧴' },
    { id: '#876621', name: 'EAU DE Parfum', color: '#FFD88D', icon: '✨' },
  ];

  const timeline = ['10am', '11am', '12am', '01am', '02am', '03am', '04am', '05am', '06am', '07am'];

  return (
    <div className="bg-white border border-[#E4E4E4] rounded-3xl p-6 shadow-sm w-full flex flex-col md:flex-row gap-8 items-stretch mt-6">
      
      <div className="w-full md:w-[35%] flex flex-col justify-between">
        <div>
          <h3 className="text-lg font-bold text-[#1A1D1F] mb-4">Recent Orders</h3>
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="text-xs font-semibold text-[#6F767E] border-b border-gray-100">
                <th className="pb-3 font-medium">Tracking no</th>
                <th className="pb-3 font-medium px-2">Product Name</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 text-xs text-[#1A1D1F]">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50 transition duration-150">
                  <td className="py-3 text-gray-400 font-medium">{order.id}</td>
                  <td className="py-3 px-2 flex items-center gap-3">
                    <span 
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-xs shadow-sm"
                      style={{ backgroundColor: order.color }}
                    >
                      {order.icon}
                    </span>
                    <span className="font-semibold text-gray-800">{order.name}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="hidden md:block w-[1px] bg-gray-100 self-stretch"></div>

      <div className="flex-1 flex flex-col justify-between relative">
        
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-base font-bold text-gray-400">Reports</h3>
          <div className="flex items-center gap-4">
            <span className="text-xs font-semibold text-gray-800">Pattern</span>
            <span className="text-[#6F767E] font-bold cursor-pointer hover:text-black tracking-widest">···</span>
          </div>
        </div>

        <div className="flex-1 w-full flex gap-3 items-end h-48 mt-4 relative">
          
          {/* محور الأرقام الرأسي (Y-Axis) */}
          <div className="flex flex-col justify-between h-[85%] text-[10px] font-semibold text-gray-400 pb-2">
            <span>100</span>
            <span>80</span>
            <span>60</span>
            <span>45</span>
            <span>20</span>
            <span>0</span>
          </div>

          <div className="flex-1 h-full relative border-b border-l border-gray-50">
            <svg className="w-full h-full" viewBox="0 0 500 150" fill="none" xmlns="http://w3.org">
              
              <path 
                d="M 0 70 C 40 30, 70 30, 100 60 C 130 90, 170 90, 210 50 C 250 10, 280 15, 320 80 C 360 120, 400 40, 450 30 L 450 150 L 0 150 Z" 
                fill="url(#chart-gradient)" 
                opacity="0.08"
              />
              
              <path 
                d="M 0 70 C 40 30, 70 30, 100 60 C 130 90, 170 90, 210 50 C 250 10, 280 15, 320 80 C 360 120, 400 40, 450 30" 
                stroke="url(#line-gradient)" 
                strokeWidth="4.5" 
                strokeLinecap="round"
              />
              
              <circle cx="100" cy="60" r="5" fill="#4F86F7" stroke="white" strokeWidth="2" />
              <circle cx="210" cy="50" r="5" fill="#605BFF" stroke="white" strokeWidth="2" />
              <circle cx="320" cy="80" r="5" fill="#B578FF" stroke="white" strokeWidth="2" />

              <line x1="320" y1="80" x2="320" y2="150" stroke="#1A1D1F" strokeWidth="1" strokeDasharray="4 4" opacity="0.3" />

              <defs>
                <linearGradient id="line-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#4F86F7" />
                  <stop offset="50%" stopColor="#605BFF" />
                  <stop offset="100%" stopColor="#B578FF" />
                </linearGradient>
                <linearGradient id="chart-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#605BFF" />
                  <stop offset="100%" stopColor="transparent" />
                </linearGradient>
              </defs>
            </svg>

            <div className="absolute top-[35px] left-[61%] transform -translate-x-1/2 bg-[#1A1D1F] text-white px-3 py-1.5 rounded-xl flex flex-col items-center shadow-lg text-[10px] font-bold">
              <span className="text-gray-400 font-medium text-[8px]">Sales</span>
              <span>2,678</span>
              {/* السهم السفلي الصغير الموجه للنقطة */}
              <div className="w-2 h-2 bg-[#1A1D1F] rotate-45 absolute -bottom-1"></div>
            </div>

          </div>
        </div>

        <div className="flex justify-between text-[10px] font-bold text-gray-400 mt-2 pl-8 pr-2">
          {timeline.map((time, index) => (
            <span key={index} className={time === '03am' ? 'text-indigo-600 font-black' : ''}>
              {time}
            </span>
          ))}
        </div>

      </div>

    </div>
  );
}
