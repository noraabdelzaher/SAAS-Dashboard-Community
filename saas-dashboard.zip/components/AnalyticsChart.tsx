export default function AnalyticsChart() {
  return (
    <div className="bg-white border border-[#E4E4E4] p-6 rounded-2xl flex flex-col justify-between shadow-sm h-[380px] w-[400px]">
      
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold text-[#1A1D1F]">Analytics</h3>
        <span className="text-[#6F767E] font-bold cursor-pointer hover:text-black">•••</span>
      </div>

      <div className="flex justify-center items-center my-4">
        
        <div className="w-44 h-44 rounded-full border-[12px] border-t-[#605BFF] border-r-[#605BFF] border-b-[#FFD166] border-l-[#FF8A65] flex flex-col justify-center items-center shadow-inner relative">
          
          <span className="text-3xl font-extrabold text-[#1A1D1F]">100%</span>
          <span className="text-xs font-medium text-[#6F767E] mt-1">Transactions</span>
          
        </div>

      </div>

      <div className="flex justify-center items-center space-x-6 text-sm pt-2">
        
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 bg-[#605BFF] rounded-md"></span>
          <span className="text-[#6F767E] font-medium">Sale</span>
        </div>

        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 bg-[#FFD166] rounded-md"></span>
          <span className="text-[#6F767E] font-medium">Distribute</span>
        </div>

       
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 bg-[#FF8A65] rounded-md"></span>
          <span className="text-[#6F767E] font-medium">Return</span>
        </div>

      </div>

    </div>
  );
}
