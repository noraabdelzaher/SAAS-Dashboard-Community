import Link from 'next/link';

export default function Sidebar() {
  return (
    <aside className="w-20 h-screen bg-white border-r border-gray-100 flex flex-col items-center py-6 justify-between">
      
      <div className="w-12 h-12 rounded-xl bg-[#605BFF] flex items-center justify-center font-bold text-white text-xl">
        B
      </div>

      <nav className="flex flex-col space-y-6 items-center flex-1 justify-center">
        <Link href="/" className="w-10 h-10 bg-[#F4F4FF] text-[#605BFF] rounded-xl flex items-center justify-center font-semibold">
          🎛️
        </Link>
        <Link href="#" className="w-10 h-10 text-[#737373] hover:text-[#605BFF] hover:bg-[#F4F4FF] rounded-xl flex items-center justify-center transition">
          📊
        </Link>
        <Link href="#" className="w-10 h-10 text-[#737373] hover:text-[#605BFF] hover:bg-[#F4F4FF] rounded-xl flex items-center justify-center transition">
          💼
        </Link>
        <Link href="#" className="w-10 h-10 text-[#737373] hover:text-[#605BFF] hover:bg-[#F4F4FF] rounded-xl flex items-center justify-center transition">
          📄
        </Link>
        <Link href="#" className="w-10 h-10 text-[#737373] hover:text-[#605BFF] hover:bg-[#F4F4FF] rounded-xl flex items-center justify-center transition">
          📅
        </Link>
        <Link href="#" className="w-10 h-10 text-[#737373] hover:text-[#605BFF] hover:bg-[#F4F4FF] rounded-xl flex items-center justify-center transition relative">
          📈
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full"></span>
        </Link>
        <Link href="#" className="w-10 h-10 text-[#737373] hover:text-[#605BFF] hover:bg-[#F4F4FF] rounded-xl flex items-center justify-center transition">
          🔔
        </Link>
        <Link href="#" className="w-10 h-10 text-[#737373] hover:text-[#605BFF] hover:bg-[#F4F4FF] rounded-xl flex items-center justify-center transition">
          ⚙️
        </Link>
      </nav>

    </aside>
  );
}
