export default function Header(){
    return(
        <header className="flex justify-between items-center w-full mb-8">

            <h1 className="text-2xl font-bold text-[#1A1D1F]">
        Dashboard
            </h1>

            <div className="flex items-center space-x-3">

                <div className="bg-white border border-[#E4E4E4] px-4 py-2 rounded-xl text-sm text-[#6F767E] font-medium shadow-sm">
                    10-06-2021 📅
                </div>

                <div className="bg-white border border-[#E4E4E4] px-4 py-2 rounded-xl text-sm text-[#6F767E] font-medium shadow-sm">
                    10-10-2021 📅
                </div>

            </div>
        </header>
    );
}