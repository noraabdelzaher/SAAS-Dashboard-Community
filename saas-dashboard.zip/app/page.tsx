import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import StatCard from '../components/statcard';
import AnalyticsChart from '../components/AnalyticsChart';
import ReportsAndOrders from '@/components/ReportsAndOrders';


export default function Home(){
  return(
    <div className="flex min-h-screen w-full bg-[#FAFAFB]">

      <Sidebar/>

      <main className="flex-1 p-8">

        <Header />
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <StatCard 
            icon="🛍️" 
            iconBg="#B5E4CA" 
            value="178+" 
            title="Save Products" 
          />

          <StatCard 
            icon="📦" 
            iconBg="#CABDFF" 
            value="20+" 
            title="Stock Products" 
          />

          <StatCard 
            icon="🔥" 
            iconBg="#FFD88D" 
            value="190+" 
            title="Sale Products" 
          />

          <StatCard 
            icon="📝" 
            iconBg="#FFB7B7" 
            value="12+" 
            title="Job Application" 
          />
        </div>

         <div className="flex justify-end">
          <AnalyticsChart />
          </div>

    
            
           <ReportsAndOrders/>
           

      </main>

    </div>
  );
}


